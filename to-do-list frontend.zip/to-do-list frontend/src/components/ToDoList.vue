<template>
  <div class="container">
    <h2 class="text-center">To-Do List</h2>

    <!--Form submit-->
    <div class="d-flex mt-5">
      <input
        v-model="task"
        type="text"
        placeholder="Enter task name"
        class="form-control"
      />
      <button @click="submitTask()" class="btn btn-primary">Submit</button>
    </div>

    <!--Task overview-->
    <table class="table table-bordered mt-5">
      <thead>
        <tr>
          <th scope="col">Task</th>
          <th scope="col" class="text-center col-4">Complete?</th>
          <th scope="col" class="text-center col-2">Delete</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(task, index) in tasks" :key="index">
          <td
            :style="[
              task.IsCompleted
                ? { 'text-decoration': 'line-through' }
                : { 'text-decoration': 'none' },
            ]"
          >
            {{ task.Name }}
          </td>
          <td class="text-center">
            <div @click="updateStatus(index)">
              <span v-if="task.IsCompleted"> Complete </span>
              <span v-else> In-progress </span>
            </div>
          </td>
          <td class="text-center">
            <div @click="deleteTask(index)">
              <span class="fa fa-trash"> </span>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <input type="checkbox" id="completeOnlyCheck" @click="filterTasks()" />
    <label>See only complete</label>
  </div>
</template>

<script>
export default {
  name: "ToDoList",
  props: {
    msg: String,
  },

  data() {
    return {
      task: "",
      tasks: [],
    };
  },

  methods: {
    submitTask() {
      if (this.task.length === 0) return;

      fetch("https://localhost:44353/api/Task/Create?taskName=" + this.task, {
        method: "POST",
      })
        .then((response) => response.json())
        .then((data) => {
          this.tasks = data;
        });

      this.task = "";
    },

    filterTasks() {
      let checkbox = document.getElementById("completeOnlyCheck");
      if (checkbox.checked) {
        this.tasks = this.tasks.filter((task) => {
          return task.IsCompleted;
        });
      } else {
        this.getTasks();
      }
    },

    deleteTask(index) {
      let selectedTask = JSON.parse(JSON.stringify(this.tasks[index]));
      fetch("https://localhost:44353/api/Task/Delete/" + selectedTask.Id, {
        method: "DELETE",
      })
        .then((response) => response.json())
        .then((data) => {
          this.tasks = data;
        });
    },

    updateStatus(index) {
      let selectedTask = JSON.parse(JSON.stringify(this.tasks[index]));
      fetch("https://localhost:44353/api/Task/Update/" + selectedTask.Id, {
        method: "PATCH",
      })
        .then((response) => response.json())
        .then((data) => {
          this.tasks = data;
        });
    },

    getTasks() {
      fetch("https://localhost:44353/api/Task/Get")
        .then((response) => response.json())
        .then((data) => {
          this.tasks = data;
        });
    },
  },

  mounted() {
    this.getTasks();
  },
};
</script>

<style scoped></style>
