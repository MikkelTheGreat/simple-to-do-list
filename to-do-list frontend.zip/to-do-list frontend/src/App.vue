<script setup>
import ToDoList from "./components/ToDoList.vue";
</script>

<template>
  <main>
    <ToDoList />
  </main>
</template>

<style scoped></style>
